import React, { Component } from 'react'
//import Button from './BUTTON/button';
import Button from './button';
//import Track from './trackreq';
import './approve.css';
class Row1 extends Component {



  render() {
    return (
      
        <tr className="Row"><td>{this.props.temp.Tid}</td>
           <td> {this.props.temp.Summary}</td>
          <td> {this.props.temp.Status} </td>
          <td>{this.props.temp.Details}</td>
          <td> {this.props.Date}</td>
        </tr>

      
    );
  }
}

export default Row1;
