import React, { Component } from 'react';
class Button extends Component {
  render() {
    return (
      <input type="submit" value={this.props.value} className={this.props.className} onClick={this.props.click}/>
    );
  }
}

export default Button;
