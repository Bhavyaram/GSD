import React, { Component } from 'react'
import Main from './Api';
//import Row from './row';
//import Table from './table';
//import Header from './header';
class App extends Component {
  render() {
    return (
      <div>
     <Main/>
      </div>
    );
  }
}

export default App;
