import React, { Component } from 'react'
import Main from './main';
class Login extends Component {
  render() {
    return (
      <div>
     <input type="text"/>
     <button onClick={this.props.button}>OK</button>
      </div>
    );
  }
}

export default App;
