import React, { Component } from 'react'
//import Button from './BUTTON/button';
import Button from './button';
//import Track from './trackreq';
import './approve.css';

class Row extends Component {



  render() {
    return (
      
        <tr className="Row"><td>{this.props.temp.Tid}</td>
           <td> {this.props.temp.Summary}</td>
          <td> {this.props.temp.Status} </td>
          <td>{this.props.temp.Details}</td>
          <td> {this.props.Date}</td>
          <td> 
            <button className="approve" onClick={() => this.props.Aclick(this.props.temp.Tid, "Approved")}disabled={this.props.temp.Status !== 'Pending'}value="Approve" >  Approved </button>
      <button className="Reject" onClick={() => this.props.Aclick(this.props.temp.Tid, "Rejected")}  disabled={this.props.temp.Status !== 'Pending'} value="Reject" >Reject</button>
      </td>
        </tr>

      
    );
  }
}

export default Row;
