import React, { Component } from 'react'
import './table.css';
//import Row from './ROW/row';
class Table extends Component {

 
  render() {
    return (  
   
  <tr>
    <th>Ticket No</th>
    <th>Summary</th>
    <th>Status</th>
	<th> Details</th>
	<th>Created Date</th>
  	<th>Approve/reject</th>
  </tr>

    );
  }
}

export default Table;
