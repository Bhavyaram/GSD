 import React, { Component } from 'react'
 import './header.css';
 import Main from './main';
import Table from './table';
 class Header extends Component {
  render() {
    return (
 <div>
 
 <header>
                    GSD
		  </header>
                <fieldset className="Main">
                    <div style={{ padding: 10 }}>
                        <div className="tab">
                            <img src="pic.png" alt="GDS LOGO" />
                            <button className="RaiseRequest">RaiseRequest</button>
                            <button className="TrackRequest">TrackRequest</button>
                            <button className="Approve">Approve</button>
                        </div>
                    </div>
                    <Main/>
                    </fieldset>
                    
                    </div>
                    );
  }
}

export default Header;