import React, { Component } from 'react'
import './style.css';
import './header.css';
import Button from './button';
import './button.css';
import Table from './table';
import Row from './row';
import Row1 from './row1';
import Track from './trackreq';

class Main extends Component {
    constructor() {
        super();
        this.state = {
            color_black: true,
            temp: [
            ],
            formSubmitted: 0,
            color_black: true,
            color_red: true,
            color_yellow: true,
 value:''
        }

        this.click = this.click.bind(this);
        this.Aclick = this.Aclick.bind(this);
        this.Track = this.Track.bind(this);
        this.Raise = this.Raise.bind(this);
        this.Approve = this.Approve.bind(this);
    }

 handleValidation(){
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;

        //Name
        if(!fields["name"]){
           formIsValid = false;
           errors["name"] = "Cannot be empty";
        }

        if(typeof fields["name"] !== "undefined"){
             if(!fields["name"].match(/^[a-zA-Z]+$/)){
                 formIsValid = false;
                 errors["name"] = "Only letters";
             }          
        }
 }

    click(e) {
        let temp1 = this.state.temp;
        temp1.push({
            Tid: (Object.keys(this.state.temp).length) + 1,
            Summary: this.state.Summary,
            Details: this.state.Details,
            Status: 'Pending'
        })
        this.setState({
            temp: temp1
        });

        this.setState({ formSubmitted: 3 });
this.form.validateFields();
        if (!this.form.isValid()) {
      console.log('form is invalid: do not submit');
    } else {
      console.log('form is valid: submit');
    }
    }

    Aclick(Tid, status) {
        var temp1 = this.state.temp;
        temp1 = temp1.map(rep => {
            if (Tid === rep.Tid) {

                rep.Status = status;

            }
            return rep;
        })
        this.setState({
            temp: temp1
        })

    }

    Track(e) {

        this.setState({ color_black: !this.state.color_black })
        this.setState({ formSubmitted: 3 })
        this.setState({ color_red: '#7a7979' })
        this.setState({ color_yellow: '#7a7979' })
    }
    Raise(e) {
        this.setState({ color_red: !this.state.color_red })
        this.setState({ formSubmitted: 1 })
        this.setState({ color_black: '#7a7979' })
        this.setState({ color_yellow: '#7a7979' })
    }
    Approve(e) {
        this.setState({ color_yellow: !this.state.color_yellow })
        this.setState({ formSubmitted: 2 })
        this.setState({ color_black: '#7a7979' })
        this.setState({ color_red: '#7a7979' })
    }

    render() {

        let tColor = this.state.color_black ? "#7a7979" : "#73ccf4"
        let rColor = this.state.color_red ? "#7a7979" : "#73ccf4"
        let aColor = this.state.color_yellow ? "#7a7979" : "#73ccf4"
        return (

            <div>
                <header>
                    GSD
		  </header>
                <fieldset className="Main">
                    <div>
                        <div className="tab">
                            <img src="https://onecognizantbcapps.cognizant.com/1697/Images/logo1.png" alt="GDS LOGO" />
                            <button style={{ color: rColor }} className="RaiseRequest" onClick={this.Raise} >  Raise Request</button>
                            <button style={{ color: tColor }} className="TrackRequest" onClick={this.Track}>Track Request</button>
                            <button style={{ color: aColor }} className="Approve" onClick={this.Approve}>Approve</button>
                        </div>
                    </div>

                    {this.state.formSubmitted === 0 ?
                        <div className="login">
                            <h4>Please login with your ID/Name</h4>
                            <input className="input" type="text" value={this.state.value} onChange={e => this.setState({ value: e.target.value })} />
                            <button onClick={e => this.setState({ formSubmitted: 1 })}>OK</button>
                        </div>
                        : this.state.formSubmitted === 1 ?
                            <div>
                                <fieldset className="smallFieldset">
                                    <div>
                                        <h4>Welcome {this.state.value}, How can we help you today?</h4>
                                        <div className="Dropdown">
                                            <label className="prolabel">Problem:</label>
                                            <input list="problems" name="dropdown" onChange={e => this.setState({ Summary: e.target.value })} value={this.state.Summary} />
                                            <FieldFeedbacks for="dropdown">
            <FieldFeedback when="*"/>
          </FieldFeedbacks>

                                            <datalist id="problems">
                                                <option value="PC Admin Rights" />
                                                <option value="Software Request" />
                                                <option value="Temperature is too low getting cold here" />
                                                <option value="Tru Time Problems" />
                                                <option value="UHC problems" />
                                            </datalist>
                                        </div>
                                        <div className="Textarea">
                                            <label>Details:</label>
                                            <textarea className="comments" rows="8" cols="70" onChange={e => this.setState({ Details: e.target.value })} value={this.state.Details}>
<FieldFeedbacks for="comments">
            <FieldFeedback when="*"/>
          </FieldFeedbacks>

                                            </textarea>
                                        </div>

                                    </div>
                                </fieldset>

                                <div className="buttons">
                                    <Button className="submit" value="SUBMIT" click={this.click} />
                                    <Button className="cancel" value="CANCEL" />
                                </div>
                            </div> :
                            this.state.formSubmitted === 2 ?




                                <fieldset className="fapprove">

                                    <table>
                                        <Table />

                                        {this.state.temp.map((val, i) =>
                                            <Row key={i} temp={val} Date="25/2/17" Aclick={this.Aclick} />
                                        )

                                        }
                                    </table>

                                </fieldset> :
                                <fieldset className="fapprove">
                                    <table>
                                        <Track />


                                        {this.state.temp.map((val, i) =>

                                            < Row1 key={i} temp={val} Date="25/2/17" />
                                        )

                                        }



                                    </table>

                                </fieldset>}





                </fieldset>

            </div>
        );
    }
}

export default Main;
