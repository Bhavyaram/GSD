import React, { Component } from 'react'
import './table.css';
//import Row from './ROW/row';
class Track extends Component {

 
  render() {
    return (
      
  <tr>
    <th>Ticket No</th>
    <th>Summary</th>
    <th>Status</th>
	<th>Details</th>
	<th>Created Date</th>
  </tr>

    );
  }
}

export default Track;
